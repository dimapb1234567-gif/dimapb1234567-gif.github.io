﻿    /*
    ** Watch_Face_Editor tool v 18.1
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_alarm_clock_text_text_img = ''
        let normal_spo2_text_text_img = ''
        let normal_spo2_text_separator_img = ''
        let normal_stress_text_text_img = ''
        let normal_stress_text_separator_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_bio_charge_text_text_img = ''
        let normal_bio_charge_text_separator_img = ''
        let normal_widget_text_1 = ''
        let normal_widget_text_6 = ''
        let normal_widget_text_7 = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_temperature_current_separator_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month = ''
        let normal_date_month_separator_img = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_group_ForecastWeather = ''
        let normal_forecast_date_week_img = new Array(4);
        let normal_forecast_date_week_img_array = ['chars_728DC266_000.png', 'chars_728DC266_001.png', 'chars_728DC266_002.png', 'chars_728DC266_003.png', 'chars_728DC266_004.png', 'chars_728DC266_005.png', 'chars_728DC266_006.png'];
        let normal_forecast_average_text_img = new Array(4);
        let normal_forecast_image_progress_img_level = new Array(4);
        let normal_forecast_image_array = ['w00.png', 'w01.png', 'w02.png', 'w03.png', 'w04.png', 'w05.png', 'w06.png', 'w07.png', 'w08.png', 'w09.png', 'w10.png', 'w11.png', 'w12.png', 'w13.png', 'w14.png', 'w15.png', 'w16.png', 'w17.png', 'w18.png', 'w19.png', 'w20.png', 'w21.png', 'w22.png', 'w23.png', 'w24.png', 'w25.png', 'w26.png', 'w27.png', 'w28.png'];
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let idle_background_bg = ''
        let idle_alarm_clock_text_text_img = ''
        let idle_spo2_text_text_img = ''
        let idle_spo2_text_separator_img = ''
        let idle_stress_text_text_img = ''
        let idle_stress_text_separator_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_text_separator_img = ''
        let idle_bio_charge_text_text_img = ''
        let idle_bio_charge_text_separator_img = ''
        let idle_widget_text_1 = ''
        let idle_widget_text_6 = ''
        let idle_widget_text_7 = ''
        let idle_battery_text_text_img = ''
        let idle_battery_text_separator_img = ''
        let idle_temperature_high_text_img = ''
        let idle_temperature_low_text_img = ''
        let idle_temperature_current_text_img = ''
        let idle_temperature_current_separator_img = ''
        let idle_date_img_date_year = ''
        let idle_date_img_date_month = ''
        let idle_date_month_separator_img = ''
        let idle_date_img_date_day = ''
        let idle_date_day_separator_img = ''
        let idle_date_img_date_week_img = ''
        let idle_group_ForecastWeather = ''
        let idle_forecast_date_week_img = new Array(4);
        let idle_forecast_date_week_img_array = ['chars_728DC266_000.png', 'chars_728DC266_001.png', 'chars_728DC266_002.png', 'chars_728DC266_003.png', 'chars_728DC266_004.png', 'chars_728DC266_005.png', 'chars_728DC266_006.png'];
        let idle_forecast_average_text_img = new Array(4);
        let idle_forecast_image_progress_img_level = new Array(4);
        let idle_forecast_image_array = ['w00.png', 'w01.png', 'w02.png', 'w03.png', 'w04.png', 'w05.png', 'w06.png', 'w07.png', 'w08.png', 'w09.png', 'w10.png', 'w11.png', 'w12.png', 'w13.png', 'w14.png', 'w15.png', 'w16.png', 'w17.png', 'w18.png', 'w19.png', 'w20.png', 'w21.png', 'w22.png', 'w23.png', 'w24.png', 'w25.png', 'w26.png', 'w27.png', 'w28.png'];
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: Oswald-Medium.ttf; FontSize: 27
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 418,
              h: 55,
              text_size: 27,
              char_space: 2,
              line_space: 0,
              font: 'fonts/Oswald-Medium.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _+-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Oswald-Medium.ttf; FontSize: 23
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 363,
              h: 46,
              text_size: 23,
              char_space: 2,
              line_space: 0,
              font: 'fonts/Oswald-Medium.ttf',
              color: 0xFF0080FF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _+-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFFFFFFFF',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_clock_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 289,
              y: 409,
              font_array: ["chars_A88A0548_000.png","chars_A88A0548_001.png","chars_A88A0548_002.png","chars_A88A0548_003.png","chars_A88A0548_004.png","chars_A88A0548_005.png","chars_A88A0548_006.png","chars_A88A0548_007.png","chars_A88A0548_008.png","chars_A88A0548_009.png"],
              padding: true,
              h_space: 0,
              invalid_image: 'chars_A88A0548_010.png',
              dot_image: 'chars_A88A0548_010.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 379,
              y: 86,
              font_array: ["chars_A88A0548_000.png","chars_A88A0548_001.png","chars_A88A0548_002.png","chars_A88A0548_003.png","chars_A88A0548_004.png","chars_A88A0548_005.png","chars_A88A0548_006.png","chars_A88A0548_007.png","chars_A88A0548_008.png","chars_A88A0548_009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 333,
              y: 80,
              src: 'heart_2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 180,
              y: 86,
              font_array: ["chars_A88A0548_000.png","chars_A88A0548_001.png","chars_A88A0548_002.png","chars_A88A0548_003.png","chars_A88A0548_004.png","chars_A88A0548_005.png","chars_A88A0548_006.png","chars_A88A0548_007.png","chars_A88A0548_008.png","chars_A88A0548_009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 142,
              y: 80,
              src: 'heart_4.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 277,
              y: 86,
              font_array: ["chars_A88A0548_000.png","chars_A88A0548_001.png","chars_A88A0548_002.png","chars_A88A0548_003.png","chars_A88A0548_004.png","chars_A88A0548_005.png","chars_A88A0548_006.png","chars_A88A0548_007.png","chars_A88A0548_008.png","chars_A88A0548_009.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 234,
              y: 80,
              src: 'heart_5.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 96,
              y: 86,
              font_array: ["chars_A88A0548_000.png","chars_A88A0548_001.png","chars_A88A0548_002.png","chars_A88A0548_003.png","chars_A88A0548_004.png","chars_A88A0548_005.png","chars_A88A0548_006.png","chars_A88A0548_007.png","chars_A88A0548_008.png","chars_A88A0548_009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 54,
              y: 80,
              src: 'heart_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_1 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 8,
              y: 499,
              w: 194,
              h: 194,
              text_size: 27,
              char_space: 2,
              font: 'fonts/Oswald-Medium.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.WRAP,
              align_h: hmUI.align.CENTER_H,
              text: 'Сейчас',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_6 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 191,
              y: 489,
              w: 194,
              h: 194,
              text_size: 23,
              char_space: 2,
              font: 'fonts/Oswald-Medium.ttf',
              color: 0xFF0080FF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.WRAP,
              align_h: hmUI.align.CENTER_H,
              text: 'Мин.',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_7 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 191,
              y: 518,
              w: 194,
              h: 194,
              text_size: 23,
              char_space: 2,
              font: 'fonts/Oswald-Medium.ttf',
              color: 0xFFFF0000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.WRAP,
              align_h: hmUI.align.CENTER_H,
              text: 'Макс.',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 151,
              y: 48,
              font_array: ["chars_A88A0548_000.png","chars_A88A0548_001.png","chars_A88A0548_002.png","chars_A88A0548_003.png","chars_A88A0548_004.png","chars_A88A0548_005.png","chars_A88A0548_006.png","chars_A88A0548_007.png","chars_A88A0548_008.png","chars_A88A0548_009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 109,
              y: 36,
              src: 'bat.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 220,
              y: 434,
              font_array: ["chars_A88A0548_000.png","chars_A88A0548_001.png","chars_A88A0548_002.png","chars_A88A0548_003.png","chars_A88A0548_004.png","chars_A88A0548_005.png","chars_A88A0548_006.png","chars_A88A0548_007.png","chars_A88A0548_008.png","chars_A88A0548_009.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'chars_A88A0548_011.png',
              unit_tc: 'chars_A88A0548_011.png',
              unit_en: 'chars_A88A0548_011.png',
              negative_image: 'chars_A88A0548_010.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 220,
              y: 406,
              font_array: ["chars_A88A0548_000.png","chars_A88A0548_001.png","chars_A88A0548_002.png","chars_A88A0548_003.png","chars_A88A0548_004.png","chars_A88A0548_005.png","chars_A88A0548_006.png","chars_A88A0548_007.png","chars_A88A0548_008.png","chars_A88A0548_009.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'chars_A88A0548_011.png',
              unit_tc: 'chars_A88A0548_011.png',
              unit_en: 'chars_A88A0548_011.png',
              negative_image: 'chars_A88A0548_010.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 169,
              y: 421,
              font_array: ["chars_A88A0548_000.png","chars_A88A0548_001.png","chars_A88A0548_002.png","chars_A88A0548_003.png","chars_A88A0548_004.png","chars_A88A0548_005.png","chars_A88A0548_006.png","chars_A88A0548_007.png","chars_A88A0548_008.png","chars_A88A0548_009.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'chars_A88A0548_011.png',
              unit_tc: 'chars_A88A0548_011.png',
              unit_en: 'chars_A88A0548_011.png',
              negative_image: 'chars_A88A0548_010.png',
              invalid_image: 'chars_A88A0548_010.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 148,
              y: 410,
              src: 'hm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 296,
              year_startY: 48,
              year_sc_array: ["chars_A88A0548_000.png","chars_A88A0548_001.png","chars_A88A0548_002.png","chars_A88A0548_003.png","chars_A88A0548_004.png","chars_A88A0548_005.png","chars_A88A0548_006.png","chars_A88A0548_007.png","chars_A88A0548_008.png","chars_A88A0548_009.png"],
              year_tc_array: ["chars_A88A0548_000.png","chars_A88A0548_001.png","chars_A88A0548_002.png","chars_A88A0548_003.png","chars_A88A0548_004.png","chars_A88A0548_005.png","chars_A88A0548_006.png","chars_A88A0548_007.png","chars_A88A0548_008.png","chars_A88A0548_009.png"],
              year_en_array: ["chars_A88A0548_000.png","chars_A88A0548_001.png","chars_A88A0548_002.png","chars_A88A0548_003.png","chars_A88A0548_004.png","chars_A88A0548_005.png","chars_A88A0548_006.png","chars_A88A0548_007.png","chars_A88A0548_008.png","chars_A88A0548_009.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 262,
              month_startY: 48,
              month_sc_array: ["chars_A88A0548_000.png","chars_A88A0548_001.png","chars_A88A0548_002.png","chars_A88A0548_003.png","chars_A88A0548_004.png","chars_A88A0548_005.png","chars_A88A0548_006.png","chars_A88A0548_007.png","chars_A88A0548_008.png","chars_A88A0548_009.png"],
              month_tc_array: ["chars_A88A0548_000.png","chars_A88A0548_001.png","chars_A88A0548_002.png","chars_A88A0548_003.png","chars_A88A0548_004.png","chars_A88A0548_005.png","chars_A88A0548_006.png","chars_A88A0548_007.png","chars_A88A0548_008.png","chars_A88A0548_009.png"],
              month_en_array: ["chars_A88A0548_000.png","chars_A88A0548_001.png","chars_A88A0548_002.png","chars_A88A0548_003.png","chars_A88A0548_004.png","chars_A88A0548_005.png","chars_A88A0548_006.png","chars_A88A0548_007.png","chars_A88A0548_008.png","chars_A88A0548_009.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_month_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 285,
              y: 32,
              src: 'chars_67B8AD10_010.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 227,
              day_startY: 48,
              day_sc_array: ["chars_A88A0548_000.png","chars_A88A0548_001.png","chars_A88A0548_002.png","chars_A88A0548_003.png","chars_A88A0548_004.png","chars_A88A0548_005.png","chars_A88A0548_006.png","chars_A88A0548_007.png","chars_A88A0548_008.png","chars_A88A0548_009.png"],
              day_tc_array: ["chars_A88A0548_000.png","chars_A88A0548_001.png","chars_A88A0548_002.png","chars_A88A0548_003.png","chars_A88A0548_004.png","chars_A88A0548_005.png","chars_A88A0548_006.png","chars_A88A0548_007.png","chars_A88A0548_008.png","chars_A88A0548_009.png"],
              day_en_array: ["chars_A88A0548_000.png","chars_A88A0548_001.png","chars_A88A0548_002.png","chars_A88A0548_003.png","chars_A88A0548_004.png","chars_A88A0548_005.png","chars_A88A0548_006.png","chars_A88A0548_007.png","chars_A88A0548_008.png","chars_A88A0548_009.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 250,
              y: 32,
              src: 'chars_67B8AD10_010.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 151,
              y: 15,
              week_en: ["weekru_1.png","weekru_2.png","weekru_3.png","weekru_4.png","weekru_5.png","weekru_6.png","weekru_7.png"],
              week_tc: ["weekru_1.png","weekru_2.png","weekru_3.png","weekru_4.png","weekru_5.png","weekru_6.png","weekru_7.png"],
              week_sc: ["weekru_1.png","weekru_2.png","weekru_3.png","weekru_4.png","weekru_5.png","weekru_6.png","weekru_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();            
            // normal_Weather_FewDays = hmUI.createWidget(hmUI.widget.FewDays, {
              // x: 80,
              // y: 308,
              // ColumnWidth: 85,
              // DaysCount: 4,
            // });
            
            normal_group_ForecastWeather = hmUI.createWidget(hmUI.widget.GROUP, {
              x: 80,
              y: 308,
              h: 0,
              w: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_forecast_date_week_img = normal_group_ForecastWeather.createWidget(hmUI.widget.IMG_LEVEL_Options, {
              // x: 0,
              // y: -32,
              // image_array: ["chars_728DC266_000.png","chars_728DC266_001.png","chars_728DC266_002.png","chars_728DC266_003.png","chars_728DC266_004.png","chars_728DC266_005.png","chars_728DC266_006.png"],
              // image_length: 7,
              // type: hmUI.data_type.forecast_date_week_img,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            //#region screenType
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              for (let i = 0; i < 4; i++) {
                normal_forecast_date_week_img[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.IMG, {
                  x: 0 + i*85,
                  y: -32,
                  src: normal_forecast_date_week_img_array[0],
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              };
            };
            //#endregion

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            // normal_forecast_average_text_img = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT_IMG_Options, {
              // x: -31,
              // y: 43,
              // font_array: ["chars_67B8AD10_000.png","chars_67B8AD10_001.png","chars_67B8AD10_002.png","chars_67B8AD10_003.png","chars_67B8AD10_004.png","chars_67B8AD10_005.png","chars_67B8AD10_006.png","chars_67B8AD10_007.png","chars_67B8AD10_008.png","chars_67B8AD10_009.png"],
              // padding: false,
              // h_space: 1,
              // unit_en: 'chars_A88A0548_011.png',
              // negative_image: 'chars_A88A0548_010.png',
              // invalid_image: 'chars_A88A0548_010.png',
              // dot_image: 'chars_A88A0548_010.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.forecast_average_text_img,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            //#region screenType
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              for (let i = 0; i < 4; i++) {
                normal_forecast_average_text_img[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT_IMG, {
                  x: -31 + i*85,
                  y: 43,
                  font_array: ["chars_67B8AD10_000.png","chars_67B8AD10_001.png","chars_67B8AD10_002.png","chars_67B8AD10_003.png","chars_67B8AD10_004.png","chars_67B8AD10_005.png","chars_67B8AD10_006.png","chars_67B8AD10_007.png","chars_67B8AD10_008.png","chars_67B8AD10_009.png"],
                  padding: false,
                  h_space: 1,
                  unit_sc: 'chars_A88A0548_011.png',
                  unit_tc: 'chars_A88A0548_011.png',
                  unit_en: 'chars_A88A0548_011.png',
                  negative_image: 'chars_A88A0548_010.png',
                  align_h: hmUI.align.CENTER_H,
                  // type: hmUI.data_type.FORECAST_NUMBER_MAX,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              };
            };
            //#endregion

            // normal_forecast_image_progress_img_level = normal_group_ForecastWeather.createWidget(hmUI.widget.IMG_LEVEL_Options, {
              // x: 0,
              // y: -9,
              // image_array: ["w00.png","w01.png","w02.png","w03.png","w04.png","w05.png","w06.png","w07.png","w08.png","w09.png","w10.png","w11.png","w12.png","w13.png","w14.png","w15.png","w16.png","w17.png","w18.png","w19.png","w20.png","w21.png","w22.png","w23.png","w24.png","w25.png","w26.png","w27.png","w28.png"],
              // image_length: 29,
              // type: hmUI.data_type.forecast_image,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            //#region screenType
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              for (let i = 0; i < 4; i++) {
                normal_forecast_image_progress_img_level[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.IMG, {
                  x: 0 + i*85,
                  y: -9,
                  src: normal_forecast_image_array[25],
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              };
            };
            //#endregion

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 27,
              hour_startY: 117,
              hour_array: ["chars_2064A955_000.png","chars_2064A955_001.png","chars_2064A955_002.png","chars_2064A955_003.png","chars_2064A955_004.png","chars_2064A955_005.png","chars_2064A955_006.png","chars_2064A955_007.png","chars_2064A955_008.png","chars_2064A955_009.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 252,
              minute_startY: 117,
              minute_array: ["chars_2064A955_000.png","chars_2064A955_001.png","chars_2064A955_002.png","chars_2064A955_003.png","chars_2064A955_004.png","chars_2064A955_005.png","chars_2064A955_006.png","chars_2064A955_007.png","chars_2064A955_008.png","chars_2064A955_009.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 210,
              y: 62,
              src: 'chars_A30E3FF_000.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFFFFFFFF',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_alarm_clock_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 289,
              y: 409,
              font_array: ["chars_A88A0548_000.png","chars_A88A0548_001.png","chars_A88A0548_002.png","chars_A88A0548_003.png","chars_A88A0548_004.png","chars_A88A0548_005.png","chars_A88A0548_006.png","chars_A88A0548_007.png","chars_A88A0548_008.png","chars_A88A0548_009.png"],
              padding: true,
              h_space: 0,
              invalid_image: 'chars_A88A0548_010.png',
              dot_image: 'chars_A88A0548_010.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 379,
              y: 86,
              font_array: ["chars_A88A0548_000.png","chars_A88A0548_001.png","chars_A88A0548_002.png","chars_A88A0548_003.png","chars_A88A0548_004.png","chars_A88A0548_005.png","chars_A88A0548_006.png","chars_A88A0548_007.png","chars_A88A0548_008.png","chars_A88A0548_009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_spo2_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 333,
              y: 80,
              src: 'heart_2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stress_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 180,
              y: 86,
              font_array: ["chars_A88A0548_000.png","chars_A88A0548_001.png","chars_A88A0548_002.png","chars_A88A0548_003.png","chars_A88A0548_004.png","chars_A88A0548_005.png","chars_A88A0548_006.png","chars_A88A0548_007.png","chars_A88A0548_008.png","chars_A88A0548_009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stress_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 142,
              y: 80,
              src: 'heart_4.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 277,
              y: 86,
              font_array: ["chars_A88A0548_000.png","chars_A88A0548_001.png","chars_A88A0548_002.png","chars_A88A0548_003.png","chars_A88A0548_004.png","chars_A88A0548_005.png","chars_A88A0548_006.png","chars_A88A0548_007.png","chars_A88A0548_008.png","chars_A88A0548_009.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 234,
              y: 80,
              src: 'heart_5.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_bio_charge_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 96,
              y: 86,
              font_array: ["chars_A88A0548_000.png","chars_A88A0548_001.png","chars_A88A0548_002.png","chars_A88A0548_003.png","chars_A88A0548_004.png","chars_A88A0548_005.png","chars_A88A0548_006.png","chars_A88A0548_007.png","chars_A88A0548_008.png","chars_A88A0548_009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_bio_charge_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 54,
              y: 80,
              src: 'heart_1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_widget_text_1 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 8,
              y: 499,
              w: 194,
              h: 194,
              text_size: 27,
              char_space: 2,
              font: 'fonts/Oswald-Medium.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.WRAP,
              align_h: hmUI.align.CENTER_H,
              text: 'Сейчас',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_widget_text_6 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 191,
              y: 489,
              w: 194,
              h: 194,
              text_size: 23,
              char_space: 2,
              font: 'fonts/Oswald-Medium.ttf',
              color: 0xFF0080FF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.WRAP,
              align_h: hmUI.align.CENTER_H,
              text: 'Мин.',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_widget_text_7 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 191,
              y: 518,
              w: 194,
              h: 194,
              text_size: 23,
              char_space: 2,
              font: 'fonts/Oswald-Medium.ttf',
              color: 0xFFFF0000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.WRAP,
              align_h: hmUI.align.CENTER_H,
              text: 'Макс.',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 151,
              y: 48,
              font_array: ["chars_A88A0548_000.png","chars_A88A0548_001.png","chars_A88A0548_002.png","chars_A88A0548_003.png","chars_A88A0548_004.png","chars_A88A0548_005.png","chars_A88A0548_006.png","chars_A88A0548_007.png","chars_A88A0548_008.png","chars_A88A0548_009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 109,
              y: 36,
              src: 'bat.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 220,
              y: 434,
              font_array: ["chars_A88A0548_000.png","chars_A88A0548_001.png","chars_A88A0548_002.png","chars_A88A0548_003.png","chars_A88A0548_004.png","chars_A88A0548_005.png","chars_A88A0548_006.png","chars_A88A0548_007.png","chars_A88A0548_008.png","chars_A88A0548_009.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'chars_A88A0548_011.png',
              unit_tc: 'chars_A88A0548_011.png',
              unit_en: 'chars_A88A0548_011.png',
              negative_image: 'chars_A88A0548_010.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 220,
              y: 406,
              font_array: ["chars_A88A0548_000.png","chars_A88A0548_001.png","chars_A88A0548_002.png","chars_A88A0548_003.png","chars_A88A0548_004.png","chars_A88A0548_005.png","chars_A88A0548_006.png","chars_A88A0548_007.png","chars_A88A0548_008.png","chars_A88A0548_009.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'chars_A88A0548_011.png',
              unit_tc: 'chars_A88A0548_011.png',
              unit_en: 'chars_A88A0548_011.png',
              negative_image: 'chars_A88A0548_010.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 169,
              y: 421,
              font_array: ["chars_A88A0548_000.png","chars_A88A0548_001.png","chars_A88A0548_002.png","chars_A88A0548_003.png","chars_A88A0548_004.png","chars_A88A0548_005.png","chars_A88A0548_006.png","chars_A88A0548_007.png","chars_A88A0548_008.png","chars_A88A0548_009.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'chars_A88A0548_011.png',
              unit_tc: 'chars_A88A0548_011.png',
              unit_en: 'chars_A88A0548_011.png',
              negative_image: 'chars_A88A0548_010.png',
              invalid_image: 'chars_A88A0548_010.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 148,
              y: 410,
              src: 'hm.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 296,
              year_startY: 48,
              year_sc_array: ["chars_A88A0548_000.png","chars_A88A0548_001.png","chars_A88A0548_002.png","chars_A88A0548_003.png","chars_A88A0548_004.png","chars_A88A0548_005.png","chars_A88A0548_006.png","chars_A88A0548_007.png","chars_A88A0548_008.png","chars_A88A0548_009.png"],
              year_tc_array: ["chars_A88A0548_000.png","chars_A88A0548_001.png","chars_A88A0548_002.png","chars_A88A0548_003.png","chars_A88A0548_004.png","chars_A88A0548_005.png","chars_A88A0548_006.png","chars_A88A0548_007.png","chars_A88A0548_008.png","chars_A88A0548_009.png"],
              year_en_array: ["chars_A88A0548_000.png","chars_A88A0548_001.png","chars_A88A0548_002.png","chars_A88A0548_003.png","chars_A88A0548_004.png","chars_A88A0548_005.png","chars_A88A0548_006.png","chars_A88A0548_007.png","chars_A88A0548_008.png","chars_A88A0548_009.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 262,
              month_startY: 48,
              month_sc_array: ["chars_A88A0548_000.png","chars_A88A0548_001.png","chars_A88A0548_002.png","chars_A88A0548_003.png","chars_A88A0548_004.png","chars_A88A0548_005.png","chars_A88A0548_006.png","chars_A88A0548_007.png","chars_A88A0548_008.png","chars_A88A0548_009.png"],
              month_tc_array: ["chars_A88A0548_000.png","chars_A88A0548_001.png","chars_A88A0548_002.png","chars_A88A0548_003.png","chars_A88A0548_004.png","chars_A88A0548_005.png","chars_A88A0548_006.png","chars_A88A0548_007.png","chars_A88A0548_008.png","chars_A88A0548_009.png"],
              month_en_array: ["chars_A88A0548_000.png","chars_A88A0548_001.png","chars_A88A0548_002.png","chars_A88A0548_003.png","chars_A88A0548_004.png","chars_A88A0548_005.png","chars_A88A0548_006.png","chars_A88A0548_007.png","chars_A88A0548_008.png","chars_A88A0548_009.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_month_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 285,
              y: 32,
              src: 'chars_67B8AD10_010.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 227,
              day_startY: 48,
              day_sc_array: ["chars_A88A0548_000.png","chars_A88A0548_001.png","chars_A88A0548_002.png","chars_A88A0548_003.png","chars_A88A0548_004.png","chars_A88A0548_005.png","chars_A88A0548_006.png","chars_A88A0548_007.png","chars_A88A0548_008.png","chars_A88A0548_009.png"],
              day_tc_array: ["chars_A88A0548_000.png","chars_A88A0548_001.png","chars_A88A0548_002.png","chars_A88A0548_003.png","chars_A88A0548_004.png","chars_A88A0548_005.png","chars_A88A0548_006.png","chars_A88A0548_007.png","chars_A88A0548_008.png","chars_A88A0548_009.png"],
              day_en_array: ["chars_A88A0548_000.png","chars_A88A0548_001.png","chars_A88A0548_002.png","chars_A88A0548_003.png","chars_A88A0548_004.png","chars_A88A0548_005.png","chars_A88A0548_006.png","chars_A88A0548_007.png","chars_A88A0548_008.png","chars_A88A0548_009.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 250,
              y: 32,
              src: 'chars_67B8AD10_010.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 151,
              y: 15,
              week_en: ["weekru_1.png","weekru_2.png","weekru_3.png","weekru_4.png","weekru_5.png","weekru_6.png","weekru_7.png"],
              week_tc: ["weekru_1.png","weekru_2.png","weekru_3.png","weekru_4.png","weekru_5.png","weekru_6.png","weekru_7.png"],
              week_sc: ["weekru_1.png","weekru_2.png","weekru_3.png","weekru_4.png","weekru_5.png","weekru_6.png","weekru_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // idle_Weather_FewDays = hmUI.createWidget(hmUI.widget.FewDays, {
              // x: 80,
              // y: 308,
              // ColumnWidth: 85,
              // DaysCount: 4,
            // });
            
            idle_group_ForecastWeather = hmUI.createWidget(hmUI.widget.GROUP, {
              x: 80,
              y: 308,
              h: 0,
              w: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_forecast_date_week_img = idle_group_ForecastWeather.createWidget(hmUI.widget.IMG_LEVEL_Options, {
              // x: 0,
              // y: -32,
              // image_array: ["chars_728DC266_000.png","chars_728DC266_001.png","chars_728DC266_002.png","chars_728DC266_003.png","chars_728DC266_004.png","chars_728DC266_005.png","chars_728DC266_006.png"],
              // image_length: 7,
              // type: hmUI.data_type.forecast_date_week_img,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            //#region screenType
            if (screenType == hmSetting.screen_type.AOD) {
              for (let i = 0; i < 4; i++) {
                idle_forecast_date_week_img[i] = idle_group_ForecastWeather.createWidget(hmUI.widget.IMG, {
                  x: 0 + i*85,
                  y: -32,
                  src: idle_forecast_date_week_img_array[0],
                  show_level: hmUI.show_level.ONLY_AOD,
                });
              };
            };
            //#endregion

            // idle_forecast_average_text_img = idle_group_ForecastWeather.createWidget(hmUI.widget.TEXT_IMG_Options, {
              // x: -31,
              // y: 43,
              // font_array: ["chars_67B8AD10_000.png","chars_67B8AD10_001.png","chars_67B8AD10_002.png","chars_67B8AD10_003.png","chars_67B8AD10_004.png","chars_67B8AD10_005.png","chars_67B8AD10_006.png","chars_67B8AD10_007.png","chars_67B8AD10_008.png","chars_67B8AD10_009.png"],
              // padding: false,
              // h_space: 1,
              // unit_en: 'chars_A88A0548_011.png',
              // negative_image: 'chars_A88A0548_010.png',
              // invalid_image: 'chars_A88A0548_010.png',
              // dot_image: 'chars_A88A0548_010.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.forecast_average_text_img,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            //#region screenType
            if (screenType == hmSetting.screen_type.AOD) {
              for (let i = 0; i < 4; i++) {
                idle_forecast_average_text_img[i] = idle_group_ForecastWeather.createWidget(hmUI.widget.TEXT_IMG, {
                  x: -31 + i*85,
                  y: 43,
                  font_array: ["chars_67B8AD10_000.png","chars_67B8AD10_001.png","chars_67B8AD10_002.png","chars_67B8AD10_003.png","chars_67B8AD10_004.png","chars_67B8AD10_005.png","chars_67B8AD10_006.png","chars_67B8AD10_007.png","chars_67B8AD10_008.png","chars_67B8AD10_009.png"],
                  padding: false,
                  h_space: 1,
                  unit_sc: 'chars_A88A0548_011.png',
                  unit_tc: 'chars_A88A0548_011.png',
                  unit_en: 'chars_A88A0548_011.png',
                  negative_image: 'chars_A88A0548_010.png',
                  align_h: hmUI.align.CENTER_H,
                  // type: hmUI.data_type.FORECAST_NUMBER_MAX,
                  show_level: hmUI.show_level.ONLY_AOD,
                });
              };
            };
            //#endregion

            // idle_forecast_image_progress_img_level = idle_group_ForecastWeather.createWidget(hmUI.widget.IMG_LEVEL_Options, {
              // x: 0,
              // y: -9,
              // image_array: ["w00.png","w01.png","w02.png","w03.png","w04.png","w05.png","w06.png","w07.png","w08.png","w09.png","w10.png","w11.png","w12.png","w13.png","w14.png","w15.png","w16.png","w17.png","w18.png","w19.png","w20.png","w21.png","w22.png","w23.png","w24.png","w25.png","w26.png","w27.png","w28.png"],
              // image_length: 29,
              // type: hmUI.data_type.forecast_image,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            //#region screenType
            if (screenType == hmSetting.screen_type.AOD) {
              for (let i = 0; i < 4; i++) {
                idle_forecast_image_progress_img_level[i] = idle_group_ForecastWeather.createWidget(hmUI.widget.IMG, {
                  x: 0 + i*85,
                  y: -9,
                  src: idle_forecast_image_array[25],
                  show_level: hmUI.show_level.ONLY_AOD,
                });
              };
            };
            //#endregion

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 27,
              hour_startY: 117,
              hour_array: ["chars_2064A955_000.png","chars_2064A955_001.png","chars_2064A955_002.png","chars_2064A955_003.png","chars_2064A955_004.png","chars_2064A955_005.png","chars_2064A955_006.png","chars_2064A955_007.png","chars_2064A955_008.png","chars_2064A955_009.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 252,
              minute_startY: 117,
              minute_array: ["chars_2064A955_000.png","chars_2064A955_001.png","chars_2064A955_002.png","chars_2064A955_003.png","chars_2064A955_004.png","chars_2064A955_005.png","chars_2064A955_006.png","chars_2064A955_007.png","chars_2064A955_008.png","chars_2064A955_009.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 210,
              y: 62,
              src: 'chars_A30E3FF_000.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
            //#region weather_few_days
            function weather_few_days() {
              console.log('weather_few_days()');
              let weatherData = weatherSensor.getForecastWeather();
              let forecastData = weatherData.forecastData;

              for (let i = 0; i < 4; i++) {
                // DOW images
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  let dowIndex = timeSensor.week - 1;
                  dowIndex += i;
                  while (dowIndex >= 7) {dowIndex -= 7;}
                  normal_forecast_date_week_img[i].setProperty(hmUI.prop.SRC, normal_forecast_date_week_img_array[dowIndex]);
                };
              
                // Number_Average
                let averageTemperature = '-';
                if (i < forecastData.count) averageTemperature = parseInt((forecastData.data[i].high + forecastData.data[i].low)/2).toString();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  normal_forecast_average_text_img[i].setProperty(hmUI.prop.TEXT, averageTemperature);
                };
                
                // Images
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  let weatherIndex = 25
                  if (i < forecastData.count) weatherIndex = forecastData.data[i].index;
                  normal_forecast_image_progress_img_level[i].setProperty(hmUI.prop.SRC, normal_forecast_image_array[weatherIndex]);
                };
              
                // DOW images
                if (screenType == hmSetting.screen_type.AOD) {
                  let dowIndex = timeSensor.week - 1;
                  dowIndex += i;
                  while (dowIndex >= 7) {dowIndex -= 7;}
                  idle_forecast_date_week_img[i].setProperty(hmUI.prop.SRC, idle_forecast_date_week_img_array[dowIndex]);
                };
              
                // Number_Average
                if (screenType == hmSetting.screen_type.AOD) {
                  idle_forecast_average_text_img[i].setProperty(hmUI.prop.TEXT, averageTemperature);
                };
                
                // Images
                if (screenType == hmSetting.screen_type.AOD) {
                  let weatherIndex = 25
                  if (i < forecastData.count) weatherIndex = forecastData.data[i].index;
                  idle_forecast_image_progress_img_level[i].setProperty(hmUI.prop.SRC, idle_forecast_image_array[weatherIndex]);
                };
              
              };  // end for

            };
            //#endregion

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');

                weather_few_days();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}